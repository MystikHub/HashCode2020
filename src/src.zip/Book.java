
public class Book {
	public int bookId;
	
	public Book(int bookId) {
		this.bookId = bookId;
	}
	
	public String toString() {
		return "Score: " + bookId;
	}
}
